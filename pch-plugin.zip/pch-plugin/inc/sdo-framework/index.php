<?php
/**
 * Silence is golden.
 * Shokrino Dev Options - framework
 * Author: shokrino.com
 * Documentation: shokrino.com/docs/sdo
*/