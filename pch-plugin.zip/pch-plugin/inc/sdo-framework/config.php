<?php defined( 'SDOPATH' ) || exit;
/**
 * Config SDO framework
 */
